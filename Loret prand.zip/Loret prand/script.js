let cart = [];
let total = 0;

const TELEGRAM_TOKEN = "8450667683:AAGxJkUbwc0TaB6feEHz2798mMB9h-6oZFQ";
const CHAT_ID = "7725794663";

const cartIcon = document.getElementById("cart-icon");
const cartElem = document.getElementById("cart");
const overlay = document.getElementById("overlay");
const cartItemsElem = document.getElementById("cart-items");
const cartCountElem = document.getElementById("cart-count");
const totalPriceElem = document.getElementById("total-price");
const sendBtn = document.getElementById("send-btn");

const nameInput = document.getElementById("name");
const phoneInput = document.getElementById("phone");
const addressInput = document.getElementById("address");

// فتح وغلق السلة
cartIcon.addEventListener("click", toggleCart);
overlay.addEventListener("click", toggleCart);

function toggleCart() {
  cartElem.classList.toggle("open");
  overlay.classList.toggle("show");
}

// إضافة المنتجات للسلة
document.querySelectorAll(".product button").forEach(btn => {
  btn.addEventListener("click", function() {
    const name = this.getAttribute("data-name");
    const price = parseFloat(this.getAttribute("data-price"));
    const img = this.getAttribute("data-img");
    addToCart(name, price, img);
  });
});

function addToCart(name, price, img) {
  cart.push({name, price, img});
  total += price;
  renderCart();
}

// إزالة عنصر من السلة
function removeItem(index) {
  total -= cart[index].price;
  cart.splice(index, 1);
  renderCart();
}

// تحديث السلة
function renderCart() {
  cartItemsElem.innerHTML = "";
  cart.forEach((item, index) => {
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <img src="${item.img}">
      <div class="cart-info">
        <strong>${item.name}</strong>
        <span>${item.price} $</span>
      </div>
      <button class="remove-btn" onclick="removeItem(${index})">✖️</button>
    `;
    cartItemsElem.appendChild(div);
  });

  cartCountElem.innerText = cart.length;
  totalPriceElem.innerText = total;
}

// إرسال الطلب للبوت تيليجرام
sendBtn.addEventListener("click", function() {
  if(cart.length === 0){
    alert("السلة فارغة");
    return;
  }

  let items = cart.map(i => `- ${i.name} (${i.price}$)`).join("\n");

  const msg = `
طلب جديد - LORIT BRAND
الاسم: ${nameInput.value}
الهاتف: ${phoneInput.value}
العنوان: ${addressInput.value}

الطلبات:
${items}

المجموع: ${total}$
`;

  fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: msg
    })
  })
  .then(res => res.json())
  .then(data => {
    if(data.ok){
      alert("تم إرسال الطلب للبوت بنجاح!");
      cart = [];
      total = 0;
      renderCart();
      nameInput.value = "";
      phoneInput.value = "";
      addressInput.value = "";
    } else {
      alert("حدث خطأ، حاول مرة أخرى.");
    }
  });
});
